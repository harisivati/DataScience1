This is the README for the SuperPuTTY Application

For License information please read the License.txt included with the download

For issue tracking, documentation and downloads please visit the SuperPuTTY Project on Github
https://github.com/jimradford/superputty

The latest release is available for download at https://github.com/jimradford/superputty/releases/latest
Previous releases can be found at https://github.com/jimradford/superputty/releases
Documentation is at https://github.com/jimradford/superputty/wiki/Documentation

Get the latest news and updates on the Facebook page https://www.facebook.com/superputty
